<?php
namespace Clickatell;

class ClickatellException extends \Exception
{
    // Custom Clickatell Exception
    // ---------------------------
}