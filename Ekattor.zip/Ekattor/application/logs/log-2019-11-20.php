<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-20 04:35:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-11-20 04:35:24 --> Unable to connect to the database
ERROR - 2019-11-20 05:59:49 --> 404 Page Not Found: Uploads/admin_image
ERROR - 2019-11-20 05:59:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 06:00:21 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 06:00:57 --> 404 Page Not Found: Uploads/admin_image
ERROR - 2019-11-20 06:01:57 --> Query error: Unknown column 'school_id' in 'where clause' - Invalid query: SELECT *
FROM `frontend_events`
WHERE `school_id` = '1'
AND `timestamp` > 1574229717
 LIMIT 4
ERROR - 2019-11-20 06:02:49 --> 404 Page Not Found: Uploads/admin_image
ERROR - 2019-11-20 06:02:55 --> 404 Page Not Found: Uploads/admin_image
ERROR - 2019-11-20 06:12:14 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 06:13:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 06:19:31 --> 404 Page Not Found: Uploads/admin_image
ERROR - 2019-11-20 06:23:44 --> Query error: Unknown column 'timestamp' in 'order clause' - Invalid query: SELECT *
FROM `addons`
WHERE `status` = 1
AND `unique_identifier` = 'multi-school'
ORDER BY `timestamp` DESC
ERROR - 2019-11-20 06:24:42 --> Query error: Unknown column 'timestamp' in 'order clause' - Invalid query: SELECT *
FROM `addons`
WHERE `status` = 1
AND `unique_identifier` = 'multi-school'
ORDER BY `timestamp` DESC
ERROR - 2019-11-20 06:32:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-20 06:32:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-20 06:34:27 --> 404 Page Not Found: Home/gallery
ERROR - 2019-11-20 06:45:10 --> Query error: Unknown column 'show_on_website' in 'where clause' - Invalid query: SELECT *
FROM `addons`
WHERE `show_on_website` = 1
AND `unique_identifier` = 'multi-school'
ERROR - 2019-11-20 06:45:50 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:45:50 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:45:50 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:46:17 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:46:17 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:46:17 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:46:39 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:46:39 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:47:06 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:47:06 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:47:43 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:47:43 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:47:46 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:47:48 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:47:48 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:47:59 --> 404 Page Not Found: Home/gallery_view
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:53 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:57 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:57 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:57 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:57 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:57 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:57 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:57 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:54:57 --> 404 Page Not Found: Uploads/frontend
ERROR - 2019-11-20 06:56:56 --> 404 Page Not Found: Home/contact
ERROR - 2019-11-20 06:59:59 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'address'
ERROR - 2019-11-20 07:03:39 --> Severity: Notice --> Undefined index: address /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 25
ERROR - 2019-11-20 07:03:39 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'email'
ERROR - 2019-11-20 07:03:53 --> Severity: Notice --> Undefined index: address /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 25
ERROR - 2019-11-20 07:03:53 --> Severity: Notice --> Undefined index: email /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 25
ERROR - 2019-11-20 07:03:53 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'phone'
ERROR - 2019-11-20 07:04:05 --> Severity: Notice --> Undefined index: address /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 25
ERROR - 2019-11-20 07:04:05 --> Severity: Notice --> Undefined index: email /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 25
ERROR - 2019-11-20 07:04:05 --> Severity: Notice --> Undefined index: phone /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 25
ERROR - 2019-11-20 07:04:05 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'fax'
ERROR - 2019-11-20 07:04:50 --> Severity: Notice --> Undefined index: email /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-11-20 07:04:50 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'fax'
ERROR - 2019-11-20 07:05:17 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'fax'
ERROR - 2019-11-20 07:05:31 --> Severity: Notice --> Undefined index: fax /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-11-20 07:05:31 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'school_location'
ERROR - 2019-11-20 07:06:23 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'school_location'
ERROR - 2019-11-20 07:06:26 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'school_location'
ERROR - 2019-11-20 07:14:16 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'terms_conditions'
ERROR - 2019-11-20 07:15:34 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'terms_conditions'
ERROR - 2019-11-20 07:17:41 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT *
FROM `frontend_settings`
WHERE `type` = 'privacy_policy'
ERROR - 2019-11-20 07:37:59 --> 404 Page Not Found: Home/eventsasdadas
ERROR - 2019-11-20 08:08:22 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 08:08:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 08:11:50 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 08:11:53 --> Severity: Notice --> Undefined index: frontend_gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/alumni_event.php 55
ERROR - 2019-11-20 08:11:53 --> Severity: Notice --> Undefined property: CI_Loader::$alumni_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/alumni_event.php 56
ERROR - 2019-11-20 08:11:53 --> Severity: error --> Exception: Call to a member function get_event_image() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/alumni_event.php 56
ERROR - 2019-11-20 08:12:42 --> Severity: Notice --> Undefined index: frontend_gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/alumni_event.php 55
ERROR - 2019-11-20 08:12:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 08:12:55 --> Severity: Notice --> Undefined index: frontend_gallery_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/alumni_event.php 55
ERROR - 2019-11-20 08:14:09 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 08:27:51 --> Severity: Notice --> Undefined index: image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/alumni_gallery.php 45
ERROR - 2019-11-20 08:28:13 --> 404 Page Not Found: Home/alumni_gallery_view
ERROR - 2019-11-20 08:39:48 --> Severity: Notice --> Undefined variable: row /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/alumni_gallery_view.php 66
ERROR - 2019-11-20 08:39:48 --> Severity: Notice --> Undefined variable: row /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/alumni_gallery_view.php 66
ERROR - 2019-11-20 08:39:48 --> Severity: Notice --> Undefined variable: row /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/alumni_gallery_view.php 66
ERROR - 2019-11-20 08:39:48 --> Severity: Notice --> Undefined variable: row /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/alumni_gallery_view.php 66
ERROR - 2019-11-20 09:14:58 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-20 09:15:04 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-20 09:15:47 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-20 09:19:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-20 09:19:28 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-20 09:33:16 --> 404 Page Not Found: Superadmin/frontend_settings
ERROR - 2019-11-20 09:34:59 --> Severity: Notice --> Undefined variable: class /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/index.php 32
ERROR - 2019-11-20 09:40:03 --> Severity: Warning --> include(system_settings.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/index.php 36
ERROR - 2019-11-20 09:40:03 --> Severity: Warning --> include(): Failed opening 'system_settings.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/index.php 36
ERROR - 2019-11-20 09:40:14 --> 404 Page Not Found: Superadmin/website_settings
ERROR - 2019-11-20 09:40:17 --> Severity: Warning --> include(system_settings.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/index.php 36
ERROR - 2019-11-20 09:40:17 --> Severity: Warning --> include(): Failed opening 'system_settings.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/index.php 36
ERROR - 2019-11-20 09:40:56 --> Severity: Warning --> include(system_settings.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/index.php 36
ERROR - 2019-11-20 09:40:56 --> Severity: Warning --> include(): Failed opening 'system_settings.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/index.php 36
ERROR - 2019-11-20 10:07:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 10:09:43 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 10:10:46 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 10:12:32 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 10:13:40 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-20 10:50:27 --> 404 Page Not Found: Superadmin/teachers
ERROR - 2019-11-20 10:53:05 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 2
ERROR - 2019-11-20 10:53:05 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 3
ERROR - 2019-11-20 10:53:05 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 4
ERROR - 2019-11-20 10:53:05 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 5
ERROR - 2019-11-20 10:53:05 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 6
ERROR - 2019-11-20 10:53:05 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 7
ERROR - 2019-11-20 10:53:05 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 8
ERROR - 2019-11-20 10:53:05 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 9
ERROR - 2019-11-20 10:53:05 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 10
ERROR - 2019-11-20 10:53:25 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 2
ERROR - 2019-11-20 10:53:25 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 3
ERROR - 2019-11-20 10:53:25 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 4
ERROR - 2019-11-20 10:53:25 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 5
ERROR - 2019-11-20 10:53:25 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 6
ERROR - 2019-11-20 10:53:25 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 7
ERROR - 2019-11-20 10:53:25 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 8
ERROR - 2019-11-20 10:53:25 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 9
ERROR - 2019-11-20 10:53:25 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 10
ERROR - 2019-11-20 10:54:29 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 2
ERROR - 2019-11-20 10:54:29 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 3
ERROR - 2019-11-20 10:54:29 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 4
ERROR - 2019-11-20 10:54:29 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 5
ERROR - 2019-11-20 10:54:29 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 6
ERROR - 2019-11-20 10:54:29 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 7
ERROR - 2019-11-20 10:54:29 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 8
ERROR - 2019-11-20 10:54:29 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 9
ERROR - 2019-11-20 10:54:29 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 10
ERROR - 2019-11-20 11:04:42 --> Severity: Warning --> include(../website_settings/general_settings.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 13
ERROR - 2019-11-20 11:04:42 --> Severity: Warning --> include(): Failed opening '../website_settings/general_settings.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 13
ERROR - 2019-11-20 11:04:57 --> Severity: Warning --> include(../website_settings/general_settings.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 13
ERROR - 2019-11-20 11:04:57 --> Severity: Warning --> include(): Failed opening '../website_settings/general_settings.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/website_settings.php 13
ERROR - 2019-11-20 11:19:06 --> Severity: Notice --> Undefined index: website_title /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 16
ERROR - 2019-11-20 11:26:42 --> Severity: Notice --> Undefined index: facebook /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 28
ERROR - 2019-11-20 11:27:26 --> Severity: Notice --> Undefined index: facebook /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 30
ERROR - 2019-11-20 11:30:33 --> Severity: Notice --> Undefined index: facebook /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 25
ERROR - 2019-11-20 11:32:11 --> Severity: Notice --> Undefined index: facebook /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 25
ERROR - 2019-11-20 11:32:34 --> Severity: Notice --> Undefined index: facebook /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/general_settings.php 4
ERROR - 2019-11-20 11:32:35 --> Severity: Notice --> Undefined index: facebook /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 25
ERROR - 2019-11-20 11:34:17 --> Severity: Notice --> Trying to get property 'facebook' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 28
ERROR - 2019-11-20 12:02:57 --> Severity: error --> Exception: Call to undefined method Settings_model::get_header_logo() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/general_settings.php 117
ERROR - 2019-11-20 12:05:11 --> Severity: Warning --> move_uploaded_file(uploads/logo/header-logo.png): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 290
ERROR - 2019-11-20 12:05:11 --> Severity: Warning --> move_uploaded_file(): Unable to move '/private/var/tmp/phprOvKX7' to 'uploads/logo/header-logo.png' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 290
ERROR - 2019-11-20 12:05:21 --> Severity: Warning --> move_uploaded_file(uploads/logo/header-logo.png): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 290
ERROR - 2019-11-20 12:05:21 --> Severity: Warning --> move_uploaded_file(): Unable to move '/private/var/tmp/phplpM4SR' to 'uploads/logo/header-logo.png' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 290
ERROR - 2019-11-20 12:05:21 --> Severity: Warning --> move_uploaded_file(uploads/logo/header-logo.png): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 290
ERROR - 2019-11-20 12:05:21 --> Severity: Warning --> move_uploaded_file(): Unable to move '/private/var/tmp/phpYrHUGS' to 'uploads/logo/header-logo.png' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 290
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:32 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:35 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:37 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:43 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:15:45 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 38
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:04 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:39 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:16:46 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/events.php 36
ERROR - 2019-11-20 12:21:35 --> Severity: Notice --> Undefined variable: class /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 15
ERROR - 2019-11-20 12:21:35 --> Severity: Notice --> Undefined variable: content_page /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-20 12:21:35 --> Severity: Warning --> include(.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-20 12:21:35 --> Severity: Warning --> include(): Failed opening '.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-20 12:21:42 --> Severity: Notice --> Undefined variable: class /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 15
ERROR - 2019-11-20 12:21:42 --> Severity: Notice --> Undefined variable: content_page /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-20 12:21:42 --> Severity: Warning --> include(.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-20 12:21:42 --> Severity: Warning --> include(): Failed opening '.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-20 12:22:08 --> Severity: Notice --> Undefined variable: content_page /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-20 12:22:08 --> Severity: Warning --> include(.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-20 12:22:08 --> Severity: Warning --> include(): Failed opening '.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-20 12:52:19 --> Severity: Warning --> date() expects at least 1 parameter, 0 given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/edit_event.php 2
