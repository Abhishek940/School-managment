<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-21 10:28:42 --> 404 Page Not Found: addons/Assignment/student_assignment
ERROR - 2021-01-21 10:28:44 --> 404 Page Not Found: addons/Assignment/student_assignment
ERROR - 2021-01-21 10:28:45 --> 404 Page Not Found: addons/Assignment/student_assignment
ERROR - 2021-01-21 10:28:46 --> 404 Page Not Found: addons/Assignment/student_assignment
ERROR - 2021-01-21 10:28:52 --> 404 Page Not Found: addons//index
ERROR - 2021-01-21 10:29:02 --> 404 Page Not Found: Dashboard/index
ERROR - 2021-01-21 16:29:05 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-21 10:29:08 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/core/URI.php 328
ERROR - 2021-01-21 16:29:09 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/helpers/url_helper.php 534
ERROR - 2021-01-21 10:30:17 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/drivers/mysqli/mysqli_driver.php 324
ERROR - 2021-01-21 16:30:22 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/database/DB_query_builder.php 2418
ERROR - 2021-01-21 16:30:25 --> Severity: Warning --> preg_match(): JIT compilation failed: no more memory /Applications/MAMP/htdocs/ekattor_7.2/system/helpers/url_helper.php 534
