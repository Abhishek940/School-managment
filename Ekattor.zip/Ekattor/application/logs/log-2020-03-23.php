<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-23 09:45:32 --> 404 Page Not Found: Assets/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-23 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:33 --> 404 Page Not Found: Uploads/system
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:48:54 --> Query error: Unknown column 'superadmin_access' in 'where clause' - Invalid query: SELECT *
FROM `menus`
WHERE `parent` = 0
AND `status` = 1
AND `superadmin_access` = 1
ORDER BY `sort_order` ASC
ERROR - 2020-03-23 09:48:54 --> Severity: error --> Exception: Call to a member function result_array() on bool E:\Xampp\htdocs\ekattor_7.0\application\views\backend\navigation.php 33
ERROR - 2020-03-23 09:48:59 --> Query error: Unknown column 'superadmin_access' in 'where clause' - Invalid query: SELECT *
FROM `menus`
WHERE `parent` = 0
AND `status` = 1
AND `superadmin_access` = 1
ORDER BY `sort_order` ASC
ERROR - 2020-03-23 09:49:00 --> Severity: error --> Exception: Call to a member function result_array() on bool E:\Xampp\htdocs\ekattor_7.0\application\views\backend\navigation.php 33
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: timezone E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 25
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> date_default_timezone_set(): Timezone ID '' is invalid E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 25
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: language E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: language E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: language E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: language E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: language E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: language E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: language E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: language E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: language E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 09:49:18 --> Severity: Notice --> Undefined index: language E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 09:49:18 --> Query error: Unknown column 'superadmin_access' in 'where clause' - Invalid query: SELECT *
FROM `menus`
WHERE `parent` = 0
AND `status` = 1
AND `superadmin_access` = 1
ORDER BY `sort_order` ASC
ERROR - 2020-03-23 09:50:26 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\Xampp\htdocs\ekattor_7.0\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-03-23 09:50:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: No such host is known.  E:\Xampp\htdocs\ekattor_7.0\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-03-23 09:50:26 --> Unable to connect to the database
ERROR - 2020-03-23 09:50:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:50:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:02 --> Severity: Warning --> mysqli_connect(): (HY000/1045): Access denied for user 'superadmin@example.com'@'localhost' (using password: YES) E:\Xampp\htdocs\ekattor_7.0\application\controllers\Install.php 124
ERROR - 2020-03-23 09:51:02 --> Severity: Warning --> mysqli_close() expects parameter 1 to be mysqli, bool given E:\Xampp\htdocs\ekattor_7.0\application\controllers\Install.php 126
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 09:53:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 15:43:25 --> Severity: Notice --> Undefined index: author E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:43:26 --> Severity: Notice --> Undefined index: website_keywords E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:43:26 --> Severity: Notice --> Undefined index: website_description E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:43:26 --> Severity: Notice --> Undefined index: paypal E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:43:26 --> Severity: Notice --> Undefined index: stripe_keys E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:43:26 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 174
ERROR - 2020-03-23 15:43:26 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 181
ERROR - 2020-03-23 15:43:26 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 211
ERROR - 2020-03-23 15:43:26 --> Severity: Notice --> Undefined index: cookie_status E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 39
ERROR - 2020-03-23 10:43:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:27 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:28 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:43:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:29 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:43:29 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 15:44:35 --> Severity: Notice --> Undefined index: author E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:44:35 --> Severity: Notice --> Undefined index: website_keywords E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:44:35 --> Severity: Notice --> Undefined index: website_description E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:44:35 --> Severity: Notice --> Undefined index: paypal E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:44:36 --> Severity: Notice --> Undefined index: stripe_keys E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:44:36 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 174
ERROR - 2020-03-23 15:44:36 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 181
ERROR - 2020-03-23 15:44:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 211
ERROR - 2020-03-23 15:44:36 --> Severity: Notice --> Undefined index: cookie_status E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 39
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:36 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:44:37 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:38 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:38 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 15:44:58 --> Severity: Notice --> Undefined index: author E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:44:58 --> Severity: Notice --> Undefined index: website_keywords E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:44:58 --> Severity: Notice --> Undefined index: website_description E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:44:58 --> Severity: Notice --> Undefined index: paypal E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:44:58 --> Severity: Notice --> Undefined index: stripe_keys E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:44:58 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 174
ERROR - 2020-03-23 15:44:58 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 181
ERROR - 2020-03-23 15:44:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 211
ERROR - 2020-03-23 15:44:58 --> Severity: Notice --> Undefined index: cookie_status E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 39
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:58 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:44:59 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 15:45:15 --> Severity: Notice --> Undefined index: author E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:45:15 --> Severity: Notice --> Undefined index: website_keywords E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:45:15 --> Severity: Notice --> Undefined index: website_description E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:45:15 --> Severity: Notice --> Undefined index: paypal E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:45:15 --> Severity: Notice --> Undefined index: stripe_keys E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 15:45:15 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 174
ERROR - 2020-03-23 15:45:15 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 181
ERROR - 2020-03-23 15:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 211
ERROR - 2020-03-23 15:45:15 --> Severity: Notice --> Undefined index: cookie_status E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 39
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:15 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:16 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:17 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 10:45:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:17 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 10:45:17 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 16:10:05 --> Severity: Notice --> Undefined index: author E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:10:05 --> Severity: Notice --> Undefined index: website_keywords E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:10:05 --> Severity: Notice --> Undefined index: website_description E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:10:05 --> Severity: Notice --> Undefined index: paypal E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:10:05 --> Severity: Notice --> Undefined index: stripe_keys E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:10:05 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 174
ERROR - 2020-03-23 16:10:05 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 181
ERROR - 2020-03-23 16:10:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 211
ERROR - 2020-03-23 16:10:05 --> Severity: Notice --> Undefined index: cookie_status E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 39
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:06 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:07 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 11:10:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:25 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:10:25 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:10:26 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 16:14:52 --> Severity: Notice --> Undefined index: author E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:14:53 --> Severity: Notice --> Undefined index: website_keywords E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:14:53 --> Severity: Notice --> Undefined index: website_description E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:14:53 --> Severity: Notice --> Undefined index: paypal E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:14:53 --> Severity: Notice --> Undefined index: stripe_keys E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:14:53 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 174
ERROR - 2020-03-23 16:14:53 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 181
ERROR - 2020-03-23 16:14:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 211
ERROR - 2020-03-23 16:14:53 --> Severity: Notice --> Undefined index: cookie_status E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 39
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:53 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:54 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:55 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:14:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:14:55 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 11:17:36 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 11:17:36 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 11:17:53 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 11:17:53 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 11:19:10 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 11:19:10 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 11:19:12 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 11:19:12 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 16:21:55 --> Severity: Notice --> Undefined index: author E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:21:55 --> Severity: Notice --> Undefined index: website_keywords E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:21:55 --> Severity: Notice --> Undefined index: website_description E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:21:55 --> Severity: Notice --> Undefined index: paypal E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:21:55 --> Severity: Notice --> Undefined index: stripe_keys E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:21:55 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 174
ERROR - 2020-03-23 16:21:55 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 181
ERROR - 2020-03-23 16:21:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\payment_gateway.php 211
ERROR - 2020-03-23 16:21:55 --> Severity: Notice --> Undefined index: cookie_status E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 39
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:55 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/backend
ERROR - 2020-03-23 11:21:56 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/global
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/frontend
ERROR - 2020-03-23 11:21:57 --> 404 Page Not Found: Assets/lessons
ERROR - 2020-03-23 16:23:30 --> Severity: Notice --> Undefined index: paypal E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:23:30 --> Severity: Notice --> Undefined index: stripe_keys E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 16:23:30 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 174
ERROR - 2020-03-23 16:23:30 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 181
ERROR - 2020-03-23 16:23:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 197
ERROR - 2020-03-23 16:25:22 --> Severity: Notice --> Undefined variable: paypal E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 178
ERROR - 2020-03-23 16:25:22 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 178
ERROR - 2020-03-23 16:25:22 --> Severity: Notice --> Undefined variable: stripe E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 185
ERROR - 2020-03-23 16:25:22 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 185
ERROR - 2020-03-23 16:25:22 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 201
ERROR - 2020-03-23 16:25:22 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 225
ERROR - 2020-03-23 16:25:22 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 231
ERROR - 2020-03-23 16:25:22 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 236
ERROR - 2020-03-23 16:27:20 --> Severity: Notice --> Undefined variable: paypal E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 179
ERROR - 2020-03-23 16:27:20 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 179
ERROR - 2020-03-23 16:27:20 --> Severity: Notice --> Undefined variable: stripe E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 186
ERROR - 2020-03-23 16:27:20 --> Severity: Notice --> Trying to get property 'active' of non-object E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 186
ERROR - 2020-03-23 16:27:20 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 202
ERROR - 2020-03-23 16:27:20 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 226
ERROR - 2020-03-23 16:27:20 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 232
ERROR - 2020-03-23 16:27:20 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment\index.php 237
ERROR - 2020-03-23 17:05:29 --> Severity: Notice --> Undefined variable: invoice_details E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment_gateway\index.php 197
ERROR - 2020-03-23 17:05:29 --> Severity: Notice --> Undefined variable: invoice_details E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment_gateway\index.php 200
ERROR - 2020-03-23 17:05:29 --> Severity: Notice --> Undefined variable: invoice_details E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment_gateway\index.php 200
ERROR - 2020-03-23 17:05:29 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment_gateway\index.php 217
ERROR - 2020-03-23 17:05:29 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment_gateway\index.php 222
ERROR - 2020-03-23 17:06:04 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment_gateway\index.php 217
ERROR - 2020-03-23 17:06:04 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\parent\payment_gateway\index.php 222
ERROR - 2020-03-23 17:08:29 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 217
ERROR - 2020-03-23 17:08:29 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 222
ERROR - 2020-03-23 17:15:23 --> Severity: Notice --> Undefined index: author E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 17:15:23 --> Severity: Notice --> Undefined index: website_keywords E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 17:15:23 --> Severity: Notice --> Undefined index: website_description E:\Xampp\htdocs\ekattor_7.0\application\helpers\common_helper.php 16
ERROR - 2020-03-23 17:15:23 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 237
ERROR - 2020-03-23 17:15:23 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 242
ERROR - 2020-03-23 17:19:11 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 233
ERROR - 2020-03-23 17:19:11 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 238
ERROR - 2020-03-23 17:20:53 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 233
ERROR - 2020-03-23 17:20:53 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 238
ERROR - 2020-03-23 12:20:53 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:20:53 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 17:21:35 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 233
ERROR - 2020-03-23 17:21:35 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 238
ERROR - 2020-03-23 12:21:35 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:21:35 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 17:22:31 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 233
ERROR - 2020-03-23 17:22:32 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 238
ERROR - 2020-03-23 12:22:32 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:22:32 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:22:32 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:22:32 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 17:22:39 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 233
ERROR - 2020-03-23 17:22:39 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 238
ERROR - 2020-03-23 12:22:39 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:22:39 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:22:39 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:22:39 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 17:28:30 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 219
ERROR - 2020-03-23 17:28:31 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 224
ERROR - 2020-03-23 17:28:54 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 233
ERROR - 2020-03-23 17:28:54 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 238
ERROR - 2020-03-23 12:28:54 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:28:54 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:28:54 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 17:29:02 --> Severity: Notice --> Undefined variable: total_amount_in_this_invoice E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 213
ERROR - 2020-03-23 17:29:02 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 219
ERROR - 2020-03-23 17:29:02 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 224
ERROR - 2020-03-23 12:29:02 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:29:02 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:29:03 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 17:29:55 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 233
ERROR - 2020-03-23 17:29:55 --> Severity: Notice --> Undefined variable: total_price_of_checking_out E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 238
ERROR - 2020-03-23 12:29:55 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:29:55 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:29:55 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:30:28 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:30:28 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:30:28 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:30:56 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:30:56 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:30:57 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:31:26 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:31:26 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:31:26 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 17:31:38 --> Severity: Notice --> Undefined index: class_id E:\Xampp\htdocs\ekattor_7.0\application\models\User_model.php 887
ERROR - 2020-03-23 17:31:38 --> Severity: Notice --> Undefined index: section_id E:\Xampp\htdocs\ekattor_7.0\application\models\User_model.php 888
ERROR - 2020-03-23 17:31:57 --> Severity: Notice --> Undefined index: class_id E:\Xampp\htdocs\ekattor_7.0\application\models\User_model.php 887
ERROR - 2020-03-23 17:31:57 --> Severity: Notice --> Undefined index: section_id E:\Xampp\htdocs\ekattor_7.0\application\models\User_model.php 888
ERROR - 2020-03-23 17:34:39 --> Severity: Notice --> Undefined variable: invoice E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 233
ERROR - 2020-03-23 17:34:39 --> Severity: Notice --> Undefined variable: invoice E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 239
ERROR - 2020-03-23 17:34:41 --> Severity: Notice --> Undefined variable: invoice E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 233
ERROR - 2020-03-23 17:34:41 --> Severity: Notice --> Undefined variable: invoice E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 239
ERROR - 2020-03-23 12:34:41 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:34:41 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:34:41 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:34:41 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 17:34:44 --> Severity: Notice --> Undefined variable: invoice E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 233
ERROR - 2020-03-23 17:34:44 --> Severity: Notice --> Undefined variable: invoice E:\Xampp\htdocs\ekattor_7.0\application\views\backend\payment_gateway\index.php 239
ERROR - 2020-03-23 12:34:45 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:34:45 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:34:45 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:34:45 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:35:12 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:35:12 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:35:12 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:35:12 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 17:35:16 --> Severity: Notice --> Undefined index: class_id E:\Xampp\htdocs\ekattor_7.0\application\models\User_model.php 887
ERROR - 2020-03-23 17:35:16 --> Severity: Notice --> Undefined index: section_id E:\Xampp\htdocs\ekattor_7.0\application\models\User_model.php 888
ERROR - 2020-03-23 17:36:57 --> Severity: Notice --> Undefined index: class_id E:\Xampp\htdocs\ekattor_7.0\application\models\User_model.php 887
ERROR - 2020-03-23 17:36:58 --> Severity: Notice --> Undefined index: section_id E:\Xampp\htdocs\ekattor_7.0\application\models\User_model.php 888
ERROR - 2020-03-23 12:42:42 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:42:42 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:42:42 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:43:15 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:43:15 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:43:15 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:44:20 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:44:20 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:44:20 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:44:21 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:44:37 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:44:37 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:44:37 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:45:30 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:45:30 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:45:30 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:45:30 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:00 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:00 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:00 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:09 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:09 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:09 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:21 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:21 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:21 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:48 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:48 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:50:48 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:51:54 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:51:54 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:51:54 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:56:04 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:56:04 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 12:56:04 --> 404 Page Not Found: Assets/payment
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:46 --> 404 Page Not Found: Uploads/system
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:36:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-03-23 14:38:01 --> 404 Page Not Found: Assets/js
