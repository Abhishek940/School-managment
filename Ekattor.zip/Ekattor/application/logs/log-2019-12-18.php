<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-18 06:46:11 --> 404 Page Not Found: Login/true
ERROR - 2019-12-18 06:46:15 --> 404 Page Not Found: Login/0
ERROR - 2019-12-18 06:46:45 --> 404 Page Not Found: Login/0
ERROR - 2019-12-18 09:54:56 --> Severity: error --> Exception: Call to undefined method Crud_model::last_updated_attendance_data() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 459
ERROR - 2019-12-18 09:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 452
ERROR - 2019-12-18 09:55:11 --> Severity: error --> Exception: Call to undefined method Crud_model::last_updated_attendance_data() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 459
ERROR - 2019-12-18 10:30:26 --> Severity: Notice --> date_default_timezone_set(): Timezone ID 'Africa/Dhaka' is invalid /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/helpers/common_helper.php 25
ERROR - 2019-12-18 12:34:12 --> 404 Page Not Found: Superadmin/dashboard
ERROR - 2019-12-18 12:34:16 --> 404 Page Not Found: Superadmin/invoice
ERROR - 2019-12-18 12:51:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-18 12:51:53 --> Unable to connect to the database
ERROR - 2019-12-18 12:52:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-12-18 12:52:17 --> Unable to connect to the database
ERROR - 2019-12-18 12:53:50 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 786
