<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-11 07:09:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 07:09:29 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 07:21:21 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 07:21:34 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 07:21:43 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 07:25:39 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 07:26:22 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:02:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:02:05 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:02:09 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:02:23 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:02:26 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:02:31 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:03:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:03:22 --> Severity: Error --> Cannot declare class PHPExcel_IOFactory, because the name is already in use /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/third_party/PHPExcel/IOFactory.php 37
ERROR - 2019-12-11 10:03:34 --> Severity: Error --> Cannot declare class PHPExcel_IOFactory, because the name is already in use /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/third_party/PHPExcel/IOFactory.php 37
ERROR - 2019-12-11 10:04:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:04:06 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:04:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:04:31 --> Severity: Error --> Cannot declare class PHPExcel_IOFactory, because the name is already in use /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/third_party/PHPExcel/IOFactory.php 37
ERROR - 2019-12-11 10:04:45 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:06:19 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:12:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:25:42 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 10:30:11 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-11 11:08:38 --> 404 Page Not Found: Assets/backend
