<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-21 04:39:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-11-21 04:39:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-11-21 04:39:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-11-21 04:39:25 --> Unable to connect to the database
ERROR - 2019-11-21 04:39:25 --> Unable to connect to the database
ERROR - 2019-11-21 04:39:25 --> Unable to connect to the database
ERROR - 2019-11-21 05:22:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 05:22:24 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 05:23:57 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 06:48:25 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 06:48:27 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 06:48:32 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 07:31:31 --> Severity: Warning --> rand() expects exactly 2 parameters, 1 given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 551
ERROR - 2019-11-21 07:31:31 --> Severity: Notice --> Undefined index: image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 552
ERROR - 2019-11-21 07:31:42 --> Severity: Warning --> rand() expects exactly 2 parameters, 1 given /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 551
ERROR - 2019-11-21 07:31:42 --> Severity: Notice --> Undefined index: image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 552
ERROR - 2019-11-21 07:32:38 --> Severity: Notice --> Undefined index: image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 552
ERROR - 2019-11-21 07:32:46 --> Severity: Notice --> Undefined index: image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 552
ERROR - 2019-11-21 07:33:28 --> Severity: Warning --> move_uploaded_file(uploads/frontend/noticeboard/sYtKim6Nn5M2aly.jpg): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 552
ERROR - 2019-11-21 07:33:28 --> Severity: Warning --> move_uploaded_file(): Unable to move '/private/var/tmp/php2wIrWT' to 'uploads/frontend/noticeboard/sYtKim6Nn5M2aly.jpg' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 552
ERROR - 2019-11-21 07:49:50 --> Severity: error --> Exception: Call to undefined method Crud_model::delete_notice() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 1002
ERROR - 2019-11-21 07:49:56 --> Severity: error --> Exception: Call to undefined method Crud_model::delete_notice() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 1002
ERROR - 2019-11-21 07:50:24 --> Severity: Notice --> Undefined variable: data /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Crud_model.php 592
ERROR - 2019-11-21 07:50:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL' at line 3 - Invalid query: DELETE FROM `noticeboard`
WHERE `id` = '11'
AND  IS NULL
ERROR - 2019-11-21 07:51:59 --> 404 Page Not Found: Home/noticeboard
ERROR - 2019-11-21 07:57:41 --> 404 Page Not Found: Home/noticeboard
ERROR - 2019-11-21 07:58:10 --> 404 Page Not Found: Home/noticeboard
ERROR - 2019-11-21 07:58:34 --> 404 Page Not Found: Home/noticeboard
ERROR - 2019-11-21 07:58:37 --> 404 Page Not Found: Home/index
ERROR - 2019-11-21 07:59:11 --> Severity: Notice --> Undefined variable: active_school_id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Home.php 178
ERROR - 2019-11-21 07:59:11 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/noticeboard.php 7
ERROR - 2019-11-21 08:00:02 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/noticeboard.php 7
ERROR - 2019-11-21 08:00:42 --> Severity: error --> Exception: Call to undefined function get_noticeboard_image() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/noticeboard.php 58
ERROR - 2019-11-21 08:00:47 --> Severity: error --> Exception: Call to undefined function get_noticeboard_image() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/noticeboard.php 58
ERROR - 2019-11-21 08:01:08 --> Severity: Notice --> A non well formed numeric value encountered /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/noticeboard.php 64
ERROR - 2019-11-21 08:01:08 --> Severity: Notice --> A non well formed numeric value encountered /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/noticeboard.php 64
ERROR - 2019-11-21 08:01:08 --> Severity: Notice --> A non well formed numeric value encountered /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/noticeboard.php 64
ERROR - 2019-11-21 08:01:08 --> Severity: Notice --> A non well formed numeric value encountered /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/noticeboard.php 64
ERROR - 2019-11-21 08:05:17 --> Query error: Unknown column 'notice_id' in 'where clause' - Invalid query: SELECT *
FROM `noticeboard`
WHERE `notice_id` = '4'
ERROR - 2019-11-21 08:05:54 --> Query error: Unknown column 'create_timestamp' in 'order clause' - Invalid query: SELECT *
FROM `noticeboard`
WHERE `show_on_website` = 1
ORDER BY `create_timestamp` DESC
 LIMIT 4
ERROR - 2019-11-21 08:08:58 --> Severity: Notice --> Undefined index: title /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/frontend/ultimate/notice_details.php 37
ERROR - 2019-11-21 08:24:47 --> Query error: Unknown column 'show_on_website' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `role` = 'teacher'
AND `school_id` = '1'
AND `show_on_website` = 1
ERROR - 2019-11-21 08:25:26 --> Query error: Unknown column 'show_on_website' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `role` = 'teacher'
AND `school_id` = '1'
AND `show_on_website` = 1
ERROR - 2019-11-21 08:25:56 --> Query error: Unknown column 'show_on_website' in 'field list' - Invalid query: UPDATE `users` SET `name` = 'Reuben Odonnell', `email` = 'huruki@mailinator.com', `phone` = '+1 (924) 378-1432', `gender` = 'Others', `blood_group` = 'o+', `address` = 'Nisi quaerat id con', `show_on_website` = '1'
WHERE `id` = '29'
AND `school_id` = '1'
ERROR - 2019-11-21 08:26:02 --> Query error: Unknown column 'show_on_website' in 'field list' - Invalid query: UPDATE `users` SET `name` = NULL, `email` = NULL, `phone` = NULL, `gender` = NULL, `blood_group` = NULL, `address` = NULL, `show_on_website` = NULL
WHERE `id` = '29'
AND `school_id` IS NULL
ERROR - 2019-11-21 08:27:20 --> Query error: Unknown column 'show_on_website' in 'field list' - Invalid query: UPDATE `users` SET `name` = 'Reuben Odonnell', `email` = 'huruki@mailinator.com', `phone` = '+1 (924) 378-1432', `gender` = 'Others', `blood_group` = 'o+', `address` = 'Nisi quaerat id con', `show_on_website` = '1'
WHERE `id` = '29'
AND `school_id` = '1'
ERROR - 2019-11-21 09:00:29 --> Severity: Notice --> Undefined property: CI_Loader::$alumni_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 38
ERROR - 2019-11-21 09:00:29 --> Severity: error --> Exception: Call to a member function get_photos_by_gallery_id() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 38
ERROR - 2019-11-21 09:00:44 --> Severity: Notice --> Undefined property: CI_Loader::$alumni_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 38
ERROR - 2019-11-21 09:00:44 --> Severity: error --> Exception: Call to a member function get_photos_by_gallery_id() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 38
ERROR - 2019-11-21 09:00:48 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 16
ERROR - 2019-11-21 09:00:48 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-21 09:00:48 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 18
ERROR - 2019-11-21 09:00:48 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2019-11-21 09:00:48 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 20
ERROR - 2019-11-21 09:00:48 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 21
ERROR - 2019-11-21 09:00:48 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 22
ERROR - 2019-11-21 09:00:48 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 23
ERROR - 2019-11-21 09:00:48 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 24
ERROR - 2019-11-21 09:00:48 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 09:00:48 --> Severity: Warning --> include(.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 09:00:48 --> Severity: Warning --> include(): Failed opening '.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 09:00:52 --> Severity: Notice --> Undefined property: CI_Loader::$alumni_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 38
ERROR - 2019-11-21 09:00:52 --> Severity: error --> Exception: Call to a member function get_photos_by_gallery_id() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 38
ERROR - 2019-11-21 09:01:07 --> Severity: Warning --> include(superadmin/alumni_gallery/index.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/index.php 35
ERROR - 2019-11-21 09:01:07 --> Severity: Warning --> include(): Failed opening 'superadmin/alumni_gallery/index.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/index.php 35
ERROR - 2019-11-21 09:01:21 --> Severity: Warning --> include(superadmin/alumni_gallery/index.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/index.php 35
ERROR - 2019-11-21 09:01:21 --> Severity: Warning --> include(): Failed opening 'superadmin/alumni_gallery/index.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/index.php 35
ERROR - 2019-11-21 09:02:14 --> Severity: Notice --> Undefined property: CI_Loader::$alumni_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 38
ERROR - 2019-11-21 09:02:14 --> Severity: error --> Exception: Call to a member function get_photos_by_gallery_id() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 38
ERROR - 2019-11-21 09:14:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 53
ERROR - 2019-11-21 09:14:41 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 53
ERROR - 2019-11-21 09:16:14 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 48
ERROR - 2019-11-21 09:16:14 --> Severity: Notice --> Undefined index: id /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery.php 48
ERROR - 2019-11-21 09:20:32 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 16
ERROR - 2019-11-21 09:20:32 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-21 09:20:32 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 18
ERROR - 2019-11-21 09:20:32 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2019-11-21 09:20:32 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 20
ERROR - 2019-11-21 09:20:32 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 21
ERROR - 2019-11-21 09:20:32 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 22
ERROR - 2019-11-21 09:20:32 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 23
ERROR - 2019-11-21 09:20:32 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 24
ERROR - 2019-11-21 09:20:32 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 09:20:32 --> Severity: Warning --> include(.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 09:20:32 --> Severity: Warning --> include(): Failed opening '.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 09:21:48 --> 404 Page Not Found: Website_settings/gallery_image
ERROR - 2019-11-21 09:21:54 --> 404 Page Not Found: Website_settings/gallery_image
ERROR - 2019-11-21 09:22:38 --> Severity: Notice --> Undefined property: CI_Loader::$alumni_model /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery_image.php 7
ERROR - 2019-11-21 09:22:38 --> Severity: error --> Exception: Call to a member function get_gallery_image() on null /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/gallery_image.php 7
ERROR - 2019-11-21 09:25:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2019-11-21 09:25:23 --> Unable to connect to the database
ERROR - 2019-11-21 09:52:14 --> Severity: error --> Exception: Call to undefined method Frontend_model::update_frontend_gallery() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/controllers/Superadmin.php 1122
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 16
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 17
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 18
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 19
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 20
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 21
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 22
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 23
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 24
ERROR - 2019-11-21 09:54:19 --> Severity: Notice --> Undefined variable: page_content /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 09:54:19 --> Severity: Warning --> include(.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 09:54:19 --> Severity: Warning --> include(): Failed opening '.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 09:56:34 --> 404 Page Not Found: Superadmin/gallery
ERROR - 2019-11-21 09:56:39 --> 404 Page Not Found: Superadmin/gallery
ERROR - 2019-11-21 09:57:04 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: DELETE FROM `frontend_gallery`
WHERE `id` = '6'
ERROR - 2019-11-21 10:15:04 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: DELETE FROM `frontend_gallery_image`
WHERE `id` = '1'
ERROR - 2019-11-21 10:15:49 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: DELETE FROM `frontend_gallery_image`
WHERE `id` = '65'
ERROR - 2019-11-21 10:15:54 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: DELETE FROM `frontend_gallery_image`
WHERE `id` = '65'
ERROR - 2019-11-21 10:16:10 --> Severity: error --> Exception: Call to undefined method Crud_model::remove_image() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 228
ERROR - 2019-11-21 10:45:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 10:45:20 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 11:00:01 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 11:00:02 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 11:10:55 --> Severity: Notice --> Undefined index: about_us_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 315
ERROR - 2019-11-21 11:11:04 --> Severity: Notice --> Undefined index: about_us_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 315
ERROR - 2019-11-21 11:11:04 --> Severity: Notice --> Undefined index: about_us_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 315
ERROR - 2019-11-21 11:12:21 --> Severity: Notice --> Undefined index: about_us_image /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 315
ERROR - 2019-11-21 11:20:32 --> Severity: Warning --> include(terms_and_conditions.php): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 11:20:32 --> Severity: Warning --> include(): Failed opening 'terms_and_conditions.php' for inclusion (include_path='.:/usr/local/Cellar/php@7.2/7.2.13/share/php@7.2/pear') /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/index.php 27
ERROR - 2019-11-21 11:22:20 --> Query error: Unknown column 'terms_and_conditions' in 'field list' - Invalid query: UPDATE `frontend_settings` SET `terms_and_conditions` = '&lt;h1&gt;Terms of our schoolsss&lt;/h1&gt;It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#039;Content here, content here&#039;, making it look like readable English.&amp;nbsp;&lt;span&gt;It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#039;Content here, content here&#039;, making it look like readable English.&lt;br&gt;&lt;/span&gt;&lt;h3&gt;Our school historyssss&lt;/h3&gt;&lt;span&gt;Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.&lt;br&gt;&lt;/span&gt;&lt;h3&gt;Something interesting about our school&lt;/h3&gt;&lt;span&gt;There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#039;t look even slightly believable. If you are going to use a passage&lt;br&gt;&lt;/span&gt;&lt;br&gt;&lt;ul&gt;&lt;li&gt;making this the first true generator&lt;/li&gt;&lt;li&gt;to generate Lorem Ipsum which&lt;/li&gt;&lt;li&gt;but the majority have suffered alteratio&lt;/li&gt;&lt;li&gt;is that it has a more-or-less&lt;/li&gt;&lt;/ul&gt;All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.&lt;br&gt;&lt;br&gt;&lt;br&gt;'
WHERE `id` = 1
ERROR - 2019-11-21 11:32:24 --> Severity: Notice --> Undefined variable: i /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/homepage_slider.php 14
ERROR - 2019-11-21 11:32:24 --> Severity: Notice --> Undefined index:  /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/homepage_slider.php 14
ERROR - 2019-11-21 11:32:24 --> Severity: Notice --> Trying to get property 'title' of non-object /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/homepage_slider.php 14
ERROR - 2019-11-21 11:41:55 --> Severity: error --> Exception: syntax error, unexpected end of file /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/website_settings/homepage_slider.php 52
ERROR - 2019-11-21 11:48:42 --> Severity: Notice --> Undefined index: slider_image_0 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 367
ERROR - 2019-11-21 11:48:42 --> Severity: Notice --> Undefined index: slider_image_0 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:48:42 --> Severity: Notice --> Undefined index: slider_image_0 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:48:42 --> Severity: Notice --> Undefined index: slider_image_1 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 367
ERROR - 2019-11-21 11:48:42 --> Severity: Notice --> Undefined index: slider_image_1 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:48:42 --> Severity: Notice --> Undefined index: slider_image_1 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:48:42 --> Severity: Notice --> Undefined index: slider_image_2 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 367
ERROR - 2019-11-21 11:48:42 --> Severity: Notice --> Undefined index: slider_image_2 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:48:42 --> Severity: Notice --> Undefined index: slider_image_2 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:51:10 --> Severity: Notice --> Undefined index: slider_image_0 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 367
ERROR - 2019-11-21 11:51:10 --> Severity: Notice --> Undefined index: slider_image_0 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:51:10 --> Severity: Notice --> Undefined index: slider_image_0 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:51:10 --> Severity: Notice --> Undefined index: slider_image_1 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 367
ERROR - 2019-11-21 11:51:10 --> Severity: Notice --> Undefined index: slider_image_1 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:51:10 --> Severity: Notice --> Undefined index: slider_image_1 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:51:10 --> Severity: Notice --> Undefined index: slider_image_2 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 367
ERROR - 2019-11-21 11:51:10 --> Severity: Notice --> Undefined index: slider_image_2 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:51:10 --> Severity: Notice --> Undefined index: slider_image_2 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 373
ERROR - 2019-11-21 11:52:30 --> Severity: Notice --> Undefined index: slider_image_0 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 381
ERROR - 2019-11-21 11:53:46 --> Severity: Notice --> Undefined index: slider_image_0 /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 381
ERROR - 2019-11-21 11:54:39 --> Severity: Warning --> move_uploaded_file(uploads/frontend/slider/6c0f021bb7b6fb8b93c144a229c924d5.png): failed to open stream: No such file or directory /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 372
ERROR - 2019-11-21 11:54:39 --> Severity: Warning --> move_uploaded_file(): Unable to move '/private/var/tmp/php6goadT' to 'uploads/frontend/slider/6c0f021bb7b6fb8b93c144a229c924d5.png' /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/models/Frontend_model.php 372
ERROR - 2019-11-21 11:57:27 --> Query error: Unknown column 'title' in 'field list' - Invalid query: UPDATE `frontend_settings` SET `title` = 'Have an aim in life, continuously acquire knowledge', `description` = '&quot;Never stop fighting until you arrive at your destined place&quot; - &lt;i&gt;A.P.J. Abdul Kalam&lt;/i&gt;', `image` = '2019-09-29 (2).jpg', `slider_images` = '[{\"title\":\"Education is the most powerful weapon\",\"description\":\"&quot;You can use education to change the world&quot; - &lt;i&gt;Nelson Mandela&lt;\\/i&gt;\",\"image\":\"9fa580df0232082ed3ec34a9c36ca4a8.png\"},{\"title\":\"Knowledge is power\",\"description\":\"&quot;Education is the premise of progress, in every society, in every family&quot; - &lt;i&gt;Kofi Annan&lt;\\/i&gt;\",\"image\":\"1.jpg\"},{\"title\":\"Have an aim in life, continuously acquire knowledge\",\"description\":\"&quot;Never stop fighting until you arrive at your destined place&quot; - &lt;i&gt;A.P.J. Abdul Kalam&lt;\\/i&gt;\",\"image\":\"2019-09-29 (2).jpg\"}]'
WHERE `id` = 1
ERROR - 2019-11-21 12:06:31 --> 404 Page Not Found: Assets/frontend
ERROR - 2019-11-21 12:16:04 --> Severity: error --> Exception: Call to undefined method Settings_model::get_white_logo() /Users/creativeitem/Sites/Archive/Products/Ekattor/web/codeigniter/ekattor-7/application/views/backend/superadmin/settings/system_settings.php 113
ERROR - 2019-11-21 12:34:55 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 12:34:56 --> 404 Page Not Found: Assets/backend
ERROR - 2019-11-21 12:35:25 --> 404 Page Not Found: Assets/backend
