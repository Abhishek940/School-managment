<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-09 05:23:17 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-09 05:23:18 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-09 06:52:04 --> 404 Page Not Found: Archive/products
ERROR - 2019-12-09 07:57:16 --> 404 Page Not Found: Assets/backend
ERROR - 2019-12-09 09:55:38 --> 404 Page Not Found: Assets/backend
